package org.mathpiper.ui.gui.applications.circuitpiper.model.linearalgebra;

public class WireEquationVector extends EquationVector {
    
    WireEquationVector(String description)
    {
        super(description);
    }
}

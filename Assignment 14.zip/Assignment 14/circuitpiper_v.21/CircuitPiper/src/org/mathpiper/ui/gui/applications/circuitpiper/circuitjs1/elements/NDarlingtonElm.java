package org.mathpiper.ui.gui.applications.circuitpiper.circuitjs1.elements;

public class NDarlingtonElm extends DarlingtonElm {

    public NDarlingtonElm(int xx, int yy) throws Exception {
        super(xx, yy, false);
    }

    public Class getDumpClass() {
        return DarlingtonElm.class;
    }
}

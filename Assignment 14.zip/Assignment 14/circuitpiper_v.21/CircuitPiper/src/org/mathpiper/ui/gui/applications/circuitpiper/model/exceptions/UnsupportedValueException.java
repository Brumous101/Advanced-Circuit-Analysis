package org.mathpiper.ui.gui.applications.circuitpiper.model.exceptions;

public class UnsupportedValueException extends Exception
{
    public UnsupportedValueException(String message)
    {
        super(message);
    }  
}

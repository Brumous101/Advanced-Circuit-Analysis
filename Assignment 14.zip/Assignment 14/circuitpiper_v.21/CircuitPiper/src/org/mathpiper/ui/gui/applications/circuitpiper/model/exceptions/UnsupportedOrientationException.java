package org.mathpiper.ui.gui.applications.circuitpiper.model.exceptions;


public class UnsupportedOrientationException extends Exception
{
    public UnsupportedOrientationException(String message)
    {
        super(message);
    }
}

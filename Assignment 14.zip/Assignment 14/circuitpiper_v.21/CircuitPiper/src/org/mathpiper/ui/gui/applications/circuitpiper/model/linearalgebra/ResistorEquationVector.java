package org.mathpiper.ui.gui.applications.circuitpiper.model.linearalgebra;

public class ResistorEquationVector extends EquationVector {
    
    ResistorEquationVector(String description)
    {
        super(description);
    }
}
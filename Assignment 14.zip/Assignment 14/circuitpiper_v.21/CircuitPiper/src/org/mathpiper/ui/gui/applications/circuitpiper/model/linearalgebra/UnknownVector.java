package org.mathpiper.ui.gui.applications.circuitpiper.model.linearalgebra;

public class UnknownVector extends Vector {
    
    UnknownVector(String description)
    {
        super(description);
    }
}

package org.mathpiper.ui.gui.consoles;


public interface RenderingComponent
{
    void setScale(int scale);
}
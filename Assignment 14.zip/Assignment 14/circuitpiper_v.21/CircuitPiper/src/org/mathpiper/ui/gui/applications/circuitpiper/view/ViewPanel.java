package org.mathpiper.ui.gui.applications.circuitpiper.view;

public interface ViewPanel {

    void setViewScale(double viewScale);

    void repaint();

}
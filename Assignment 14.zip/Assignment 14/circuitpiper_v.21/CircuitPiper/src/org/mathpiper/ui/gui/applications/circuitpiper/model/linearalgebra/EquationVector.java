package org.mathpiper.ui.gui.applications.circuitpiper.model.linearalgebra;

public class EquationVector extends Vector {
    
    EquationVector(String description)
    {
        super(description);
    }
    
}

package org.mathpiper.ui.gui.applications.circuitpiper.model.linearalgebra;

public class ColumnVector extends Vector {
    ColumnVector(String description)
    {
        super(description);
    }
}

package org.mathpiper.ui.gui.applications.circuitpiper.model.linearalgebra;

public class CapacitorEquationVector extends EquationVector {
    
    CapacitorEquationVector(String description)
    {
        super(description);
    }
}

package org.mathpiper.ui.gui.applications.circuitpiper.model.exceptions;


public class UnsupportedPrefixException extends Exception
{
    public UnsupportedPrefixException(String message)
    {
        super(message);
    }
}
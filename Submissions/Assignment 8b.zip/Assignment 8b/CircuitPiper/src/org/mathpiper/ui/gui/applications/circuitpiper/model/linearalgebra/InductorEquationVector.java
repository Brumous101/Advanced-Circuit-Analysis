package org.mathpiper.ui.gui.applications.circuitpiper.model.linearalgebra;

public class InductorEquationVector extends EquationVector {
    
    InductorEquationVector(String description)
    {
        super(description);
    }
}
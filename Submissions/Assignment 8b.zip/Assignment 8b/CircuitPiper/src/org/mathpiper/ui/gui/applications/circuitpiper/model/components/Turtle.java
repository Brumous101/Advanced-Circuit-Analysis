package org.mathpiper.ui.gui.applications.circuitpiper.model.components;

public interface Turtle
{
    public String getTurtle();
}

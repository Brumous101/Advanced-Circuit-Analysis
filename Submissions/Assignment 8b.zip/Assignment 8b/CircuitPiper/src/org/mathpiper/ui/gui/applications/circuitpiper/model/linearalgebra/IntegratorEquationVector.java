package org.mathpiper.ui.gui.applications.circuitpiper.model.linearalgebra;

public class IntegratorEquationVector extends EquationVector {
    
    IntegratorEquationVector(String description)
    {
        super(description);
    }
}
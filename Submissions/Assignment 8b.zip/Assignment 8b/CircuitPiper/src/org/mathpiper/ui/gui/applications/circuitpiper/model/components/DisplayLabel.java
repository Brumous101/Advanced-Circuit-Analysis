package org.mathpiper.ui.gui.applications.circuitpiper.model.components;


public interface DisplayLabel {
    
    String getDisplayLabel() throws Exception;
    
}

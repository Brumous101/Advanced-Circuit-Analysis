package org.mathpiper.ui.gui.applications.circuitpiper.model.linearalgebra;

public class MeterEquationVector extends EquationVector {
    
    MeterEquationVector(String description)
    {
        super(description);
    }
}
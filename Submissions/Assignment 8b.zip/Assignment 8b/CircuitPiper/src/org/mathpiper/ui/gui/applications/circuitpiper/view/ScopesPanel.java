package org.mathpiper.ui.gui.applications.circuitpiper.view;

import javax.swing.JPanel;
import org.mathpiper.ui.gui.VerticalFlow;

public class ScopesPanel extends JPanel
{
   // JPanel scopes = new JPanel();
    
    public ScopesPanel()
    {
        
       this.setLayout(new VerticalFlow());
        
       //this.add(scopes);
    }
    
    /*
    public void add(ScopePanel scopePanel)
    {
        scopes.add(scopePanel);
    }
    
    public void remove(ScopePanel scopePanel)
    {
        scopes.remove(scopePanel);
    }
    */
}
